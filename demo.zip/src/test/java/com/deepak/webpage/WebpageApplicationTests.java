package com.deepak.webpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebpageApplicationTests {

	@Test
	void contextLoads() {
	}

}
